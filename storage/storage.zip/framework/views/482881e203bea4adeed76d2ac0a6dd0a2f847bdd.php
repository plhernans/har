<?php $__env->startSection('content'); ?>
    <form id="faddvessel" name="faddvessel" class="_tcvessels">
        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-6 col-xl-6 m-auto">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Agregar Buque</h4>
                    <hr>

                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 mx-0 px-0">
                        <table id="tableTcBuque" class="col-12 col-lg-12 table table-hover table-sm">
                            <thead class="thead-light">
                            <tr class="justify-content-between">
                                <th scope="col"><?php echo e(__("Nombre Buque.")); ?></th>
                                <th scope="col"><?php echo e(__("No. IMO.")); ?></th>
                                <th scope="col" colspan="2" style="text-align: center"></th>
                            </tr>
                            </thead>
                            <tbody id="tableTcBuqueBody">
                                <?php $__currentLoopData = $tcbuque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buqueitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-idvessel="<?php echo e($buqueitem->idvessel); ?>" data-name="<?php echo e($buqueitem->name); ?>" data-noimo="<?php echo e($buqueitem->noimo); ?>">
                                        <td class="rowtdbuque"><?php echo e($buqueitem->idvessel); ?></td>
                                        <td class="rowtdbuque"><?php echo e($buqueitem->name); ?></td>
                                        <td class="rowtdbuque"><?php echo e($buqueitem->noimo); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-sm-6 mr-4">
                            <label for="lbltcbuque"><strong><?php echo e(__("Nombre del Buque")); ?></strong></label>
                            <input id="tcbuque" class="form-control form-control-sm" type="text" name="tcbuque" required>
                        </div>
                        <div class="form-group col-sm-5">
                            <label for="lbltcimo"><strong><?php echo e(__("No. Imo")); ?></strong></label>
                            <input type="number" id="tcbuqueimo" class="form-control form-control-sm" type="text" name="tcbuqueimo" required>
                        </div>
                    </div>
                </div>
                <div class="car-footer ml-auto mr-5">
                    <button class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tcvessels.blade.php ENDPATH**/ ?>