<?php $__env->startSection('content'); ?>


<div class="col-xs-12 col-sm-12 col-md-10 col-lg-8 col-xl-8 m-auto rounded">
    <div class="card">
        <div class="card-body">
            <h3 class="card-title"><?php echo e(__("Agregar un Puerto")); ?></h3>

            <div class="col-*-12 row formpuerto">
                <form id="formtcpuerto" name="formtcpuerto" class="formtcpuerto col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6" method="POST" action="<?php echo e(route('tcport.store')); ?>">
                    <div class="col-*-12 m-auto">
                        <div class="card">
                            <div class="card-body">

                                <input type="text"
                                    id="user"
                                    name="user"
                                    class="form-control"
                                    value="<?php echo e(Auth()->user()->id); ?>"
                                    disabled
                                    readonly
                                    hidden>
                                <div class="form-row">
                                    <div class="form-group col-sm-12 mr-4">
                                        <label for="lblpais"><?php echo e(__("Pais")); ?></label>
                                        <input id="txtpais"  class="form-control form-control-sm" type="text" required>
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblpuerto"><?php echo e(__("Puerto")); ?></label>
                                        <input id="txtpuerto" class="form-control form-control-sm" type="text" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblcodigo"><?php echo e(__("Codigo")); ?></label>
                                        <input id="txtcodigo" class="form-control form-control-sm" type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer mr-4 ml-auto">
                                <button id="btnAddPort" class="btn btn-sm btn-outline-success mb-2"><?php echo e(__("Agregar")); ?></button>
                            </div>
                        </div>
                    </div>



                </form>

                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 mx-0 px-0">
                    <table id="tableTcPort" class="col-12 col-lg-12 table table-hover table-sm">
                        <thead class="thead-light">
                        <tr>
                            <button id="btnSavePort" class="btn btn-sm btn-primary mb-2" hidden><?php echo e(__("Guardar")); ?></button>
                        </tr>
                        <tr class="justify-content-between">
                            <th scope="col"><?php echo e(__("Pais")); ?></th>
                            <th scope="col"><?php echo e(__("Puerto")); ?></th>
                            <th scope="col"><?php echo e(__("Codigo")); ?></th>
                            <th scope="col" colspan="2" style="text-align: center"></th>
                        </tr>
                        </thead>
                        <tbody id="tableTcPortBody">
                           <!-- <tr>
                                <td id="tdguestname" class="rowtdguest"></td>
                                <td id="tdguestlastname" class="rowtdguest"></td>
                                <td id="tdguestnationality" class="rowtdguest"></td>
                                <td id="tdguestpassport" class="rowtdguest"></td>
                            </tr> -->
                        </tbody>
                    </table>

                </div>



            </div>
           <!-- <div class="car-footer">
                <div class="justify-content-between align-items-right">
                    <button class="btn btn-sm btn-primary">{ __("Guardar") }}</button>
                </div>

            </div>-->
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tcports.blade.php ENDPATH**/ ?>