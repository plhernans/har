<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('modals.mReserva', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('reserva.findPort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container mx-auto px-2 rounded">

        <div class="row p-0">
            <div class="row px-1 mx-1 col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

                <!-- CARD LEFT-->
                <div class="card card-left col-md-3 mx-1 px-0 mb-1">

                    <div class="card-header bg-primary text-white col-md-12 m-0 p-2" style="max-height:40px"> Buque / Viaje</div>

                    <div class="card-body p-0">
                        <table id="leftTable" class="table table-sm table-hover leftTable">
                            <thead class="thead-light theadReservaLeft">
                                <tr class="justify-content-between">
                                    <th scope="col" hidden><?php echo e(__("idviaje")); ?></th>
                                    <th scope="col" hidden><?php echo e(__("idbuque")); ?></th>
                                    <th scope="col"><?php echo e(__("Buque")); ?></th>
                                    <th scope="col"><?php echo e(__("Viaje")); ?></th>

                                </tr>
                            </thead>
                            <tbody id="tbodyReservaLeft" class="tbodyReservaLeft">
                                <?php $__currentLoopData = $vbuqueviaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buqueviajeitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-idviaje="<?php echo e($buqueviajeitem->idviaje); ?>" data-idbuque="<?php echo e($buqueviajeitem->idbuque); ?>" data-buque="<?php echo e($buqueviajeitem->buque); ?>" data-viaje="<?php echo e($buqueviajeitem->viaje); ?>">
                                        <td class="rowtdbuque" hidden><?php echo e($buqueviajeitem->idviaje); ?></td>
                                        <td class="rowtdbuque" hidden><?php echo e($buqueviajeitem->idbuque); ?></td>
                                        <td class="rowtdbuque"><?php echo e($buqueviajeitem->buque); ?></td>
                                        <td class="rowtdbuque"><?php echo e($buqueviajeitem->viaje); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- CARD CENTER-->
                <div class="card card-right col-md-8 mx-1 px-0 mb-1">

                    <div class="card-header bg-primary text-white col-md-12 m-0 p-2 headerBooking row justify-content-between align-content-center" style="max-height: 40px">
                        <div id="bkheadervessel"></div>
                        <div id="bkheadervoyage"></div>
                    </div>

                    <div class="card-body p-0">
                        <table id="rightTableBk" class="table table-sm table-hover rightTableBk">
                            <thead class="thead-light theadReservaRight">
                                <tr>
                                    <th colspan="3">
                                        <button class="btn btn-sm btn-outline-success btnNuevaReserva" disabled><?php echo e(__("New Booking")); ?></button>
                                    </th>

                                </tr>
                                <tr class="justify-content-between">
                                    <th scope="col"><?php echo e(__("Booking No.")); ?></th>
                                    <th scope="col"><?php echo e(__("Shipper")); ?></th>
                                    <th scope="col"><?php echo e(__("Consignee")); ?></th>
                                </tr>
                            </thead>
                            <tbody id="tbodyReservaRight" class="tbodyReservaRight">
                               <tr>
                                    <td class="rowtdreserva" >4UMHAV45</td>
                                    <td class="rowtdreserva" >GLOSHIMA SA</td>
                                    <td class="rowtdreserva">ALIMPORT</td>
                                </tr>
                                <tr>
                                    <td class="rowtdreserva" >21ESP-EM0045</td>
                                    <td class="rowtdreserva" >GLOSHIMA SA</td>
                                    <td class="rowtdreserva">EXPEDIMAR</td>
                                </tr>
                                <tr>
                                    <td class="rowtdreserva" >21DOM-EM0045</td>
                                    <td class="rowtdreserva" >GLOSHIMA SA</td>
                                    <td class="rowtdreserva">AUSA</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Reserva/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Reserva/createBooking.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/reserva/frameReserva.blade.php ENDPATH**/ ?>