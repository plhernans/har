<div class="modal mt-5 fade" id="mGoodsbl">
    <div id="mGoodsblDialog" class="modal-dialog modal-lg-dialog mGoodsbl">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formgoodsbl" class="formgoodsbl" lass="formgoodsbl">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                                <div style="font-size: 15px"><strong><?php echo e(__('Description of Goods')); ?></strong></div>
                                <button id="btnCloseGoodsBl" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="card-body row p-0">
                                <div class="col-sm-5 mt-1">
                                    <div class="form-row ml-1">
                                        <div class="form-group col-sm-12">
                                            <label><strong><?php echo e(__("Booking No.")); ?></strong></label>
                                            <input id="bookingnoGoodsBl" type="text" class="form-control" disabled readonly>
                                        </div>
                                        <div class="form-group col-sm-12">
                                            <label><strong><?php echo e(__("Equipment No.")); ?></strong></label>
                                            <input id="txtequipmentno" type="text" class="form-control txtequipmentno" disabled readonly>
                                        </div>
                                    </div>
                                    <div class="form-row ml-1">
                                        <div class="form-group col-sm-12 ml-1">
                                            <label><strong><?php echo e(__("Pkgs Num")); ?></strong></label>
                                            <input id="txtpkgs" class="form-control form-control-sm txtpkgs" type="number" required>
                                        </div>
                                     </div>
                                    <div class="form-row ml-1">
                                        <div class="form-group col-sm-12 ml-1">
                                            <label><strong><?php echo e(__("Pkgs Type")); ?></strong></label>
                                            <input id="txtpkgstype" class="form-control form-control-sm txtpkgstype" type="text" required>
                                        </div>

                                    </div>
                                    <div class="form-row ml-1">
                                        <div class="form-group col-sm-12 ml-1">
                                            <label><strong><?php echo e(__("Gross Weight")); ?></strong></label>
                                            <input id="txtgrossbl" class="form-control form-control-sm txtgrossbl" type="text" disabled required>
                                        </div>
                                    </div>
                                    <div class="form-row ml-1">
                                        <div class="form-group col-sm-12 ml-1">
                                            <label><strong><?php echo e(__("Cbms")); ?></strong></label>
                                            <input id="txtcbms" class="form-control form-control-sm txtcbms" type="text" required>
                                        </div>
                                    </div>

                                </div>

                                <div class="col-sm-7 p-0">
                                    <div class="form-row mt-4">
                                        <div class="form-check-inline ml-3">
                                            <label class="form-check-label">
                                            <input type="radio" class="form-check-input" value="gc" name="optradio" checked><?php echo e(__("General Cargo")); ?>

                                            </label>
                                        </div>

                                        <div class="form-check-inline ml-3">
                                            <label class="form-check-label">
                                            <input type="radio" class="form-check-input" value="dc" name="optradio"><?php echo e(__("Dangerous Cargo")); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-row mt-4">
                                        <div class="form-group col-sm-10 m-auto">
                                            <label><strong><?php echo e(__("Goods Description")); ?></strong></label>
                                            <textarea id="txtgooddescrbl" row="35" class="form-control form-control-sm txtgooddescrbl" style="height: 100px" required></textarea>
                                        </div>
                                    </div>
                                    <div id="fieldimo" class="form-row mt-4" hidden>
                                        <label id="titleDangerCargoes" class="form-group m-auto text-red"><strong><?php echo e(__("IMO Specifications")); ?></strong></label>
                                        <div class="form-group col-sm-10 m-auto" >
                                            <label><strong><?php echo e(__("Class")); ?></strong></label>
                                            <input id="txtimoclassbl" class="form-control form-control-sm txtimoclassbl">
                                        </div>
                                    </div>
                                    <div id="fieldun" class="form-row mt-4" hidden>
                                        <div class="form-group col-sm-10 m-auto">
                                            <label><strong><?php echo e(__("U.N Number")); ?></strong></label>
                                            <input id="txtimounbl" class="form-control form-control-sm txtimounbl">
                                        </div>
                                    </div>
                                    <div id="fieldfp" class="form-row mt-4 mb-2" hidden>
                                        <div class="form-group col-sm-10 m-auto">
                                            <label><strong><?php echo e(__("Flash Point")); ?></strong></label>
                                            <input id="txtimoflashpointbl" class="form-control form-control-sm txtimoflashpointbl">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer bg-light p-1 d-flex justify-content-between align-items-center">
                                <button id="btnSaveGoodsBl" type="button" class="btn btn-sm btn-outline-primary m-2"><i class="fa fa-save mr-1"></i><?php echo e(__("Save")); ?></button>
                                <button id="btnUpdateGoodsBl" type="button" class="btn btn-sm btn-outline-primary m-2"><i class="fa fa-retweet mr-1"></i><?php echo e(__("Update")); ?></button>
                                <button id="btnCloseGoodsBl" type="button" class="btn btn-sm btn-danger m-2"><?php echo e(__("Close")); ?>

                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlbillstore" href="<?php echo e(route('bill.store')); ?>" hidden></a>

            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/billoflading/mGoodsbl.blade.php ENDPATH**/ ?>