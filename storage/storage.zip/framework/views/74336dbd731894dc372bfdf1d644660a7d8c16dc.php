<?php $__env->startSection('content'); ?>
    <div class="tablacontrol-cliente col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php echo $__env->make('modals.mCliente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="div-mbody col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="col-12">
                <table id="tableTcCliente" class="col-12 col-lg-12 table table-hover table-sm">
                    <thead class="thead-light">
                        <tr>
                            <button id="btnAddCliente" class="btn btn-sm btn-outline-primary btnAddCliente mb-1"><?php echo e(__("Agregar Cliente")); ?></button>
                        </tr>
                        <tr class="justify-content-between">
                            <th scope="col" hidden><?php echo e(__("No.")); ?></th>
                            <th scope="col"><?php echo e(__("Nombre Cliente.")); ?></th>
                            <th scope="col"><?php echo e(__("Direccion")); ?></th>
                            <th scope="col"><?php echo e(__("Codigo Postal")); ?></th>
                            <th scope="col"><?php echo e(__("Estado")); ?></th>
                            <th scope="col" colspan="2" style="text-align: center"></th>
                        </tr>
                    </thead>
                    <tbody id="tableTcClienteBody">
                        <?php $__currentLoopData = $tccliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clienteitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-idcustomers="<?php echo e($clienteitem->idcustomers); ?>" data-name="<?php echo e($clienteitem->name); ?>" data-address="<?php echo e($clienteitem->address); ?>" data-zipcode="<?php echo e($clienteitem->zipcode); ?>" data-state="<?php echo e($clienteitem->state); ?>">
                                <td class="rowtdbuque" hidden><?php echo e($clienteitem->idcustomers); ?></td>
                                <td class="rowtdbuque"><?php echo e($clienteitem->name); ?></td>
                                <td class="rowtdbuque"><?php echo e($clienteitem->address); ?></td>
                                <td class="rowtdbuque"><?php echo e($clienteitem->zipcode); ?></td>
                                <td class="rowtdbuque"><?php echo e($clienteitem->state); ?></td>
                                <td><button class="btn btn-sm btn-warning btnEditarCliente">Editar</button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Tc/CreaTcCliente.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Tc/ActualizaTcCliente.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tccliente.blade.php ENDPATH**/ ?>