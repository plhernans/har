<?php $__env->startSection('content'); ?>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
        <div class="card">

            <div class="card-header bg-primary text-white pt-1" style="height: 30px">
                <div style="font-size: 15px"><strong><?php echo e(__('Booking')); ?></strong></div>
            </div>
            <div class="card-header bg-light pt-1 pb-1" style="height: 35px">
                <button class="btn btn-dark btn-sm btnPanelNewBooking" style="font-size: 12px"><?php echo e(__('New Booking')); ?></button>
            </div>

            <div class="card-body cardbodyPanelBooking">
                <?php echo $__env->make('booking.bookinglist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('booking.bookingnew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


        </div>
        <div class="card-footer p-1 d-flex justify-content-between">
            <!-- <div class="btn-group ml-auto"> -->
                 <button id="btnSaveBooking" type="button" class="btn btn-sm btn-primary mb-1 mr-1" hidden><i class="fa fa-save mr-1"></i><?php echo e(__("Save Booking")); ?></button>
                 <button id="btnUpdateBooking" type="button" class="btn btn-sm btn-outline-primary mb-1 mr-1" hidden><?php echo e(__("Update")); ?></button>
             <!--v</div> -->
         </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Reserva/createBooking.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/booking/panelBooking.blade.php ENDPATH**/ ?>