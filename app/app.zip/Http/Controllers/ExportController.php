<?php

namespace App\Http\Controllers;

use App\Exports\MftoExport;
use Illuminate\Http\Request;
use App\Models\Vmanifiesto;
use Maatwebsite\Excel\Facades\Excel;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx as WriterXlsx;

class ExportController extends Controller
{
    public function export($id){
        $emb =$id;
        $File="mfto";

        $mfto=Vmanifiesto::where('embarque', '=', $emb)
            ->orderBy("operacion")
            ->get();

        $export = new MftoExport($mfto);
        return Excel::download($export, $File.'.xlsx');
    }

}
