<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('modals.mGoods', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mx-0 px-2 rounded">
        <table id="tableTcGoods" class="col-12 col-lg-12 table table-bordered table-sm">
            <thead class="thead-light">
                <tr>
                    <button id="btnAddGoods" class="btn btn-sm btn-outline-primary btnAddGoods mb-1"><?php echo e(__("Add Goods")); ?></button>
                </tr>
                <tr class="justify-content-between">
                    <th scope="col" ><?php echo e(__("No")); ?></th>
                    <th scope="col"><?php echo e(__("Description")); ?></th>
                    <th scope="col" colspan="2" style="text-align: center"></th>
                </tr>
            </thead>
            <tbody id="tableTcGoodsBody">
                <?php $__currentLoopData = $tcgoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goodsitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-idgoods="<?php echo e($goodsitem->idgoods); ?>" data-description="<?php echo e($goodsitem->description); ?>">
                        <td class="rowtdbuque"><?php echo e($goodsitem->idgoods); ?></td>
                        <td class="rowtdbuque"><?php echo e($goodsitem->description); ?></td>
                        <td><button class="btn btn-sm btn-warning btnEditGoods"><?php echo e(__("Edit")); ?></button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Tc/CreaTcGoods.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Tc/ActualizaTcGoods.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tcgoods.blade.php ENDPATH**/ ?>