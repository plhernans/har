<?php $__env->startSection('content'); ?>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
        <div class="card">

            <div class="card-header bg-primary text-white pt-1" style="height: 30px">
                <div style="font-size: 15px"><strong><?php echo e(__('Booking')); ?></strong></div>
            </div>
            <div class="card-header bg-light pt-1" style="height: 30px">
                <button class="btn btn-link btn-sm" style="font-size: 12px"><?php echo e(__('New Booking')); ?></button>
            </div>

            <div class="card-body cardbodyPanelBooking">
                <div id="cardlist" class="card">
                    <div class="card-header bg-light pt-1" style="height: 30px">
                        <div style="font-size: 15px"><strong><?php echo e(__('List of Booking')); ?></strong></div>
                    </div>
                    <div class="card-header bg-default pt-1" style="height: 34px">
                        <div class="row">
                            <div class="p-0" style="font-size: 14px"><button class="btn btn-sm btn-warning"><?php echo e(__('Edit Booking')); ?></button></div>
                            <div class="ml-1 p-0" style="font-size: 14px"><button class="btn btn-sm btn-danger"><?php echo e(__('Delete Booking')); ?></button></div>
                        </div>

                    </div>
                    <div class="card-body cardbodyListBooking pt-1 px-0">
                        <table class="table table-hover table-sm">
                            <thead class="thead bg-light">
                                <tr>
                                    <th><input type="checkbox"></td>
                                    <th><?php echo e(__('Vessel')); ?></td>
                                    <th><?php echo e(__('Voyage')); ?></td>
                                    <th><?php echo e(__('No. Booking')); ?></td>
                                    <th><?php echo e(__('Shipper')); ?></td>
                                    <th><?php echo e(__('No. BL')); ?></td>
                                    <th><?php echo e(__('Status')); ?></td>
                                    <th><?php echo e(__('Date')); ?></td>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $vbooking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vbookingitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-vessel="<?php echo e($vbookingitem->vessel); ?>" data-voyage="<?php echo e($vbookingitem->voyage); ?>" data-nobooking="<?php echo e($vbookingitem->nobooking); ?>" data-shipper="<?php echo e($vbookingitem->shipper); ?>" data-bl="<?php echo e($vbookingitem->bl); ?>" data-created_at="<?php echo e($vbookingitem->created_at); ?>">
                                        <td><input type="checkbox"></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->vessel); ?></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->voyage); ?></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->nobooking); ?></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->shipper); ?></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->bl); ?></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->bl ? 'CONFIRM':'PENDANT'); ?></td>
                                        <td class="rowtdbooking"><?php echo e($vbookingitem->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/reserva/panelBooking.blade.php ENDPATH**/ ?>