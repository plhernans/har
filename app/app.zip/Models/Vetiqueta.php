<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Vetiqueta
 *
 * @property string $no_orden
 * @property string $no_embarque
 * @property string $remitente
 * @property string|null $destinatario
 * @property string|null $ci
 * @property string $telefono
 * @property string|null $direccion
 * @property string $provincia
 * @property string $municipio
 * @property string|null $codprovincia
 * @property string $descripcion
 * @property string $cantidadpiezas
 * @property int $bulto
 * @property int|null $cantidad
 * @property string|null $codigobarra
 * @property string|null $noblhouse
 * @property int $idproducto
 * @property int $noproducto
 * @property int $idetiqueta
 * @property int $idorden
 * @property string|null $estado
 * @property Carbon $fecha
 * @property string $codigoenvio
 *
 * @package App\Models
 */
class Vetiqueta extends Model
{
	protected $table = 'vetiquetas';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'bulto' => 'int',
		'cantidad' => 'int',
		'idproducto' => 'int',
		'noproducto' => 'int',
		'idetiqueta' => 'int',
		'idorden' => 'int'
	];

	protected $dates = [
		'fecha'
	];

	protected $fillable = [
		'no_orden',
		'no_embarque',
		'remitente',
		'destinatario',
		'ci',
		'telefono',
		'direccion',
		'provincia',
		'municipio',
		'codprovincia',
		'descripcion',
		'cantidadpiezas',
		'bulto',
		'cantidad',
		'codigobarra',
		'noblhouse',
		'idproducto',
		'noproducto',
		'idetiqueta',
		'idorden',
		'estado',
		'fecha',
		'codigoenvio'
	];

    public function scopeNoBl($query, $nobl) {
    	if ($nobl) {
    		return $query->where('noblhouse','like',"%$nobl%");
    	}
    }

    public function scopeEmbarque($query, $noembarque) {
    	if ($noembarque) {
    		return $query->where('no_embarque','=',$noembarque);
    	}
    }

    public function scopeTipoEnvio($query, $tipoenvio) {
    	if ($tipoenvio != 'TODOS') {
    		return $query->where('codigoenvio','like',"%$tipoenvio%");
    	}
    }

    public function scopeEstado($query, $estado) {
    	if ($estado != "TODOS") {
    		return $query->where('estado','=',$estado);
    	}
    }
}
