

<div id="cardlistbooking" class="card">
    <div class="card-header bg-light pt-1" style="height: 30px">
        <div style="font-size: 15px"><?php echo e(__('List of Booking')); ?></div>
    </div>
    <div class="card-body cardbodyListBooking pt-1 px-0">
        <table class="table table-hover table-sm">
            <thead class="thead bg-light">
                <tr>
                    <th><?php echo e(__('Vessel')); ?></td>
                    <th><?php echo e(__('Voyage')); ?></td>
                    <th><?php echo e(__('No. Booking')); ?></td>
                    <th><?php echo e(__('Shipper')); ?></td>
                    <th><?php echo e(__('No. BL')); ?></td>
                    <th><?php echo e(__('Status')); ?></td>
                    <th><?php echo e(__('Date')); ?></td>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $vbooking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vbookingitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-vessel="<?php echo e($vbookingitem->vessel); ?>" data-voyage="<?php echo e($vbookingitem->voyage); ?>" data-nobooking="<?php echo e($vbookingitem->nobooking); ?>" data-shipper="<?php echo e($vbookingitem->shipper); ?>" data-bl="<?php echo e($vbookingitem->bl); ?>" data-created_at="<?php echo e($vbookingitem->created_at); ?>">
                        <td class="rowtdbooking"><?php echo e($vbookingitem->vessel); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbookingitem->voyage); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbookingitem->nobooking); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbookingitem->shipper); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbookingitem->bl); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbookingitem->bl ? 'CONFIRM':'PENDANT'); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbookingitem->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/booking/bookinglist.blade.php ENDPATH**/ ?>