<div class="modal mt-5 fade" id="m-nuevoembarque">
    <div id="m-nuevoembarqueDialog" class="modal-dialog modal-lg-dialog m-nuevoembarque">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formNuevoEmbarque" class="formNuevoEmbarque" method="POST" action="#">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <h3><?php echo e(__('Nuevo Embarque')); ?></h3>
                                <hr>
                                <div id="fielddg" class="form-row pt-2">
                                    <div class="form-group col-sm-4">
                                        <label for="lblorigen"><strong><?php echo e(__("Origen")); ?></strong></label>
                                        <input id="txtorigen" class="form-control form-control-sm txtorigen" type="text" name="txtorigen">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblembarcador"><strong><?php echo e(__("Embarcador")); ?></strong></label>
                                        <input id="txtembarcador" class="form-control form-control-sm txtembarcador" type="text" name="txtembarcador">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblconsignado"><strong><?php echo e(__("Consignado")); ?></strong></label>
                                        <input id="txtconsignado" class="form-control form-control-sm txtconsignado" type="text" name="txtconsignado">
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="lbloperacion"><strong><?php echo e(__("Operacion")); ?></strong></label>
                                        <input id="txtoperacion" class="form-control form-control-sm txtoperacion" type="text" name="txtoperacion">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblbuque"><strong><?php echo e(__("Buque")); ?></strong></label>
                                        <input id="txtbuque" class="form-control form-control-sm txtbuque" type="text" name="txtbuque">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblviaje"><strong><?php echo e(__("Viaje")); ?></strong></label>
                                        <input id="txtviaje" class="form-control form-control-sm txtviaje" type="text" name="txtviaje">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblfechaest"><strong><?php echo e(__("Fecha Est.")); ?></strong></label>
                                        <input id="txtfechaest" class="form-control form-control-sm txtfechaest" type="text" name="txtfechaest">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpol"><strong><?php echo e(__("POL")); ?></strong></label>
                                        <input id="txtpol" class="form-control form-control-sm txtpol" type="text" name="txtpol">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpod"><strong><?php echo e(__("POD")); ?></strong></label>
                                        <input id="txtpod" class="form-control form-control-sm txtpod" type="text" name="txtpod">
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="lblcont"><strong><?php echo e(__("No. Cont")); ?></strong></label>
                                        <input id="txtcont" class="form-control form-control-sm txtviaje" type="text" name="txtcont">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpesob"><strong><?php echo e(__("Peso Bruto")); ?></strong></label>
                                        <input id="txtpesob" class="form-control form-control-sm txtpesob" type="text" name="txtpesob">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpeson"><strong><?php echo e(__("Peso Neto")); ?></strong></label>
                                        <input id="txtpeson" class="form-control form-control-sm txtpeson" type="text" name="txtpeson">
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lbltara"><strong><?php echo e(__("Tara")); ?></strong></label>
                                        <input id="txttara" class="form-control form-control-sm txttara" type="text" name="txttara">
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer ml-auto mr-4">
                                <button id="btn-guardembarque" class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btn-actBuque" class="btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btn-closeembarque"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/m-nuevoembarque.blade.php ENDPATH**/ ?>