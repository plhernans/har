<?php

namespace App\Http\Controllers\Etiqueta;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ProductsExport;
use App\Models\Vetiqueta;
use App\Models\Vetiquetasresumen;

class EtiquetaController extends Controller
{
    //
    public function index()
    {
        return view('etiquetas.etiqueta');
    }

    //Obtiene el listado de etiquetas segun filtros de busquedas
    public function getListado(Request $request)
    {
        if ($request->isMethod('post')){
            $fechadesde = $request->input("desde");
            $fechahasta = $request->input("hasta");
            $nobl = $request->input("bl");
            $noembarque = $request->input("noembarque");
            $codigoenvio = $request->input("codigoenvio");
            $estado = $request->input("estado");

            $jsondata=array();
            $jsondata['data'] = Vetiqueta::where('fecha','>=',$fechadesde)->where('fecha','<=',$fechahasta)->NoBl($nobl)->Embarque($noembarque)->TipoEnvio($codigoenvio)->estado($estado)->get()->all();

            if($jsondata['data'] == null){
                $jsondata['success'] = false;
                $jsondata['message'] = 'Request made';
                echo json_encode($jsondata);

            }
            else{
                $jsondata['success'] = true;
                $jsondata['message'] = 'Request made';
                echo json_encode($jsondata);

            }
        }
    }

    //Genera etiquetas
    public function generatePDF(Request $request)
    {
        $customPaper = array(0,0,305.00,489.00);
        $etiquetas=vetiqueta::where('noproducto',$request->param)->orderBy('codigobarra','ASC')->get();
        $pdf = PDF::loadView('etiquetas.etiquetaPdf',compact('etiquetas'))->setPaper($customPaper);;
        // dd($etiquetas[0]->codigobarra);
        $path = public_path('/pdf');
        $fileName =  $etiquetas[0]->codigobarra.'.pdf' ;
        // $pdf->save($path . '/' . $fileName);
        $pdf->save($path . '/' . $fileName);
        $pdf = public_path('pdf/'.$fileName);
        $cb =$etiquetas[0]->codigobarra;

        // $pdf->download($pdf);

        return response()->json([
            'success' => 'false',
            'message'=>'descargado',
            'data'=>$cb
        ]);
    }

    public function generatePDFResumen(Request $request)
    {
        $customPaper = array(0,0,305.00,489.00);
        $etiquetas=Vetiquetasresumen::where('no_orden',$request->param)->orderBy('codigobarra','ASC')->get();
        $etiqueta_child=Vetiqueta::where('no_orden',$request->param)->where('no_orden','like','ENV%')->orderBy('codigobarra','ASC')->get(['codigobarra','noblhouse']);

        // dd($etiquetas);

        $pdf = PDF::loadView('etiquetas.etiquetaResume',compact('etiquetas','etiqueta_child'))->setPaper($customPaper);;
        // dd($etiquetas[0]->codigobarra);
        $path = public_path('/pdf');
        $fileName =  $etiquetas[0]->codigobarra.'.pdf' ;
        // $pdf->save($path . '/' . $fileName);
        $pdf->save($path . '/' . $fileName);
        $pdf = public_path('pdf/'.$fileName);
        $cb =$etiquetas[0]->codigobarra;

        // $pdf->download($pdf);

        return response()->json([
            'success' => 'false',
            'message'=>'descargado',
            'data'=>$cb
        ]);
    }
}
