<nav class="navbar navbar-expand-sm navbar-white shadow-sm bg-primary">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/index.php')); ?>">
            <?php echo e(config('app.name', 'Gloshima')); ?>

        </a>
        <button class="navbar-toggler bg-primary" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <?php if(auth()->guard()->check()): ?>
            <ul id="ulmenu" class="navbar-nav mr-auto bg-primary">

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><?php echo e(__('Embarques')); ?></a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item" href="<?php echo e(route('tcviaje.index')); ?>"><?php echo e(__('Crear Viaje')); ?></a>
                        <a class="dropdown-item" href="<?php echo e(route('maritimo.index')); ?>"><?php echo e(__('Maritimo')); ?></a>
                        <a class="dropdown-item" href="#"><?php echo e(__('Aereo')); ?></a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><?php echo e(__('Facturacion')); ?></a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item" href="#"><?php echo e(__('Generar Facturas')); ?></a>
                        <a class="dropdown-item" href="#"><?php echo e(__('Nueva Factura')); ?></a>
                        <a class="dropdown-item" href="#"><?php echo e(__('Imprimir Factura(s)')); ?></a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><?php echo e(__('Imprimir')); ?></a>
                    <div class="dropdown-menu bg-primary">
                        <a class="dropdown-item" href="#"><?php echo e(__('Listado de Embarques')); ?></a>
                        <a class="dropdown-item" href="#"><?php echo e(__('Embarques')); ?></a>
                        <a class="dropdown-item" href="#"><?php echo e(__('Ordenes')); ?></a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#"><?php echo e(__('Tables')); ?></a>
                    <div class="dropdown-menu bg-primary">
                        <a id="btnvessel" class="dropdown-item" href="<?php echo e(route('tcvessel.index')); ?>"><?php echo e(__('Vessels')); ?></a>
                        <a id="btncont" class="dropdown-item" href="<?php echo e(route('tccont.index')); ?>"><?php echo e(__('Containers')); ?></a>
                        <a id="btndelivery" class="dropdown-item" href="<?php echo e(route('tccondentrega')); ?>" hidden><?php echo e(__('Delivery Cond.')); ?></a>
                        <a id="btnport" class="dropdown-item" href="<?php echo e(route('tcport.index')); ?>"><?php echo e(__('Ports')); ?></a>
                        <a id="btnguest" class="dropdown-item" href="<?php echo e(route('tccliente.index')); ?>"><?php echo e(__('Customers')); ?></a>
                        <a id="btngoods" class="dropdown-item" href="<?php echo e(route('tcgoods.index')); ?>"><?php echo e(__('Goods')); ?></a>
                    </div>
                </li>



                

                
            </ul>

            <!-- con menus botones -->
            <!--   <div class="btn-group mr-auto">
                <div class="btn-group">
                <button type="button" id="docmenu" class="btn btn-danger dropdown-toggle" data-toggle="dropdown"><?php echo e(__('Documentacion')); ?></button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="{ route('billoflading') }}"><?php echo e(__('Bill of Lading')); ?></a>
                        <a class="dropdown-item" href="#">{ __('Etiquetas')}}</a>
                        <a class="dropdown-item" href="#">{ __('Registrar Viaje')}}</a>
                        <a class="dropdown-item" href="#">{ __('Reportes')}}</a>
                    </div>
                </div>
                <div class="btn-group">
                <button type="button" id="factmenu" class="btn btn-danger dropdown-toggle" data-toggle="dropdown"><?php echo e(__('Facturacion')); ?></button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">{ __('Facturas')}}</a>
                        <a class="dropdown-item" href="#">{ __('Reportes')}}</a>
                    </div>
                </div>
                <div class="btn-group">
                    <button type="button" id="adminmenu" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
                    { __('Administracion')}}
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">{ __('Registrar Usuario')}}</a>
                        <a class="dropdown-item" href="#">{ __('Editar Permisos') }}</a>
                    </div>
                </div>
                <div class="btn-group">
                    <button type="button" id="tcmenu" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
                    { __('Tablas de Control')}}
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="">{ __('Buque')}}</a>
                        <a class="dropdown-item" href="#">{ __('Puertos') }}</a>
                        <a class="dropdown-item" href="#">{ __('Condicion de Entrega') }}</a>
                        <a class="dropdown-item" href="#">{ __('Tipo de Contenedor') }}</a>
                    </div>
                </div>
            </div>  -->
            <?php endif; ?>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!--No Authentication Links -->
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>



                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar Session')); ?></a>
                        </li>

                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarse')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">


                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Cerrar Session')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>



                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/partials/nav.blade.php ENDPATH**/ ?>