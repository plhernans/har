<div class="modal mt-5 fade" id="m-nuevaorden">
    <div id="m-nuevaordenDialog" class="modal-dialog modal-lg-dialog m-nuevaorden">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formNuevaOrden" class="formNuevaOden" method="POST" action="#">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <h3><?php echo e(__('Nueva Orden')); ?></h3>
                                <hr>
                                <div id="fielddg" class="form-row pt-2">
                                    <div class="form-group col-sm-12">
                                        <label for="lbltipoenvio"><strong><?php echo e(__("Tipo de Envio")); ?></strong></label>
                                        <input id="txttipoenvio" class="form-control form-control-sm txttipoenvio" type="text" name="txttipoenvio">
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="lblremitente"><strong><?php echo e(__("Remitente")); ?></strong></label>
                                        <input id="txtremitente" class="form-control form-control-sm txtremitente" type="text" name="txtremitente">
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="lbldestinatario"><strong><?php echo e(__("Destinatario")); ?></strong></label>
                                        <input id="txtdestinatario" class="form-control form-control-sm txtdestinatario" type="text" name="txtdestinatario">
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer ml-auto mr-4">
                                <button id="btn-guardorden" class="btn-guardorden btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btn-actorden" class="btn-actorden btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button id="btn-closeorden" type="button" class="btn btn-sm btn-danger mb-2 btn-closeorden"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/m-nuevaorden.blade.php ENDPATH**/ ?>