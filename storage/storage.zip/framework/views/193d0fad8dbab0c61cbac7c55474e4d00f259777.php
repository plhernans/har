<?php $__env->startSection('content'); ?>
    <div class="tablacontrol-tipocontenedor col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php echo $__env->make('modals.mTipoCont', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="div-mbody col-sm-12 col-md-12 col-lg-12 col-xl-12">

            <div class="col-12">
                <table class="table table-hover table-sm table-responsive tablelistadotipocontenedor">
                    <thead class="thead-light">
                    <tr class="justify-content-between">
                        <button class="btn btn-sm btn-outline-primary btnAddCont mb-1"><?php echo e(__('Agregar Contenedor')); ?></button>
                    </tr>
                    <tr class="justify-content-between">
                        <th scope="col" class="col-1" style="text-align: center" hidden><?php echo e(__("No.")); ?></th>
                        <th scope="col" class="col-3" style="text-align: center"><?php echo e(__("Tipo Cont.")); ?></th>
                        <th scope="col" class="col-8"><?php echo e(__("Descripcion")); ?></th>
                        <th scope="col" class="col-1" style="text-align: center"><?php echo e(__("TEUS")); ?></th>
                        <th scope="col" class="col-1" style="text-align: center" colspan="3" style="text-align: center"></th>
                    </tr>
                    </thead>
                    <tbody id="tableTcTipoContBody">
                        <?php $__currentLoopData = $tccont; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-idcontainer="<?php echo e($contitem->idcontainer); ?>" data-type="<?php echo e($contitem->type); ?>" data-description="<?php echo e($contitem->description); ?>" data-teus="<?php echo e($contitem->teus); ?>">
                                <td class="rowtdtipocont" class="col-1" style="text-align: center" hidden><?php echo e($contitem->idcontainer); ?></td>
                                <td class="rowtdtipocont" class="col-3" style="text-align: center"><?php echo e($contitem->type); ?></td>
                                <td class="rowtdtipocont" class="col-8"><?php echo e($contitem->description); ?></td>
                                <td class="rowtdtipocont" class="col-1" style="text-align: center"><?php echo e($contitem->teus); ?></td>
                                <td class="col-1" style="text-align: center"><button class="btn btn-sm btn-secondary btnEditarCont"><?php echo e(__("Editar")); ?></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Tc/CreaTcCont.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Tc/ActualizaTcCont.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tccontenedor.blade.php ENDPATH**/ ?>