

<?php $__env->startSection('content'); ?>
    <form id="formguests" name="formguests" class="_tcguests">
        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-6 col-xl-6 m-auto">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e(__("Clientes")); ?></h3>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-sm-6 mr-4">
                            <label for="lbltcguest"><?php echo e(__("Nombre de Compania")); ?></label>
                            <input class="form-control" type="text" name="tcguest">
                        </div>
                        <div class="form-group col-sm-5">
                            <label for="lbltcaddress"><?php echo e(__("Direccion")); ?></label>
                            <input class="form-control" type="text" name="tcaddress">
                        </div>
                    </div>
                </div>
                <div class="car-footer">
                    <button class="btn btn-primary mb-2" style="align-items: right"><?php echo e(__("Guardar")); ?></button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tcguests.blade.php ENDPATH**/ ?>