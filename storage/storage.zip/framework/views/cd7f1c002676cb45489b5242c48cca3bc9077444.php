<div class="modal mt-5 fade" id="m-producto">
    <div id="m-productoDialog" class="modal-dialog modal-lg-dialog m-producto">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formProducto" class="formProducto" method="POST" action="#">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card contenedor-mproducto">
                            <div class="card-body">
                                <h3><strong><?php echo e(__('Nuevo Producto')); ?></strong></h3>
                                <br>
                                <h3><label class="lblnoorden-detalle ml-2 mt-1" for="noorden">ENV0001-2021 / PEDRO LUIS HERNANDEZ SAUMELL</label></h3>
                                <hr>
                                <div class="formfieldproducto col-12">
                                    <div class="form-row pt-2 pb-2">
                                        <div class="form-inline col-sm-12 col-md4 col-lg-4 col-xl-4">
                                            <label for="lblproductono" class="lbl"><strong><?php echo e(__("Producto No.: ")); ?></strong></label>
                                            <input id="txtproductono" class="form-control form-control-sm txtproductono ml-2 col-sm-8 col-md-8 col-lg-8" type="text" name="txtproductono" disabled>
                                        </div>

                                    </div>
                                    <div class="form-row pt-3">
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lbldescripcion" class="lbl"><strong><?php echo e(__("Descripcion: ")); ?></strong></label>
                                            <input type="text" id="txtdescripcion" name="txtdescripcion" class="form-control form-control-sm  ml-2 txtdescripcion col-sm-8 col-md-8 col-lg-8">
                                        </div>
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblarticulo" class="lbl"><strong><?php echo e(__("Articulo: ")); ?></strong></label>
                                            <input id="txtarticulo" class="form-control form-control-sm ml-2 txtarticulo col-sm-8 col-md-8 col-lg-8" type="text" name="txtarticulo">
                                        </div>
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblcategoria" class="lbl"><strong><?php echo e(__("Categoria: ")); ?></strong></label>
                                            <input id="txtcategoria" class="form-control form-control-sm ml-2 txtcategoria col-sm-8 col-md-8 col-lg-8" type="text" name="txtcategoria">
                                        </div>
                                    </div>
                                    <div class="form-row pt-2">
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblcantidad" class="lbl"><strong><?php echo e(__("Cantidad: ")); ?></strong></label>
                                            <input id="txtcantidad" class="form-control form-control-sm ml-2 txtcantidad col-sm-8 col-md-8 col-lg-8" type="text" name="txtcantidad">
                                        </div>
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblmcubico" class="lbl"><strong><?php echo e(__("Metros Cubico: ")); ?></strong></label>
                                            <input id="txtmcubico" class="form-control form-control-sm ml-2 txtmcubico col-sm-8 col-md-8 col-lg-8" type="text" name="txtmcubico">
                                        </div>
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblvaduana" class="lbl"><strong><?php echo e(__("Valor Aduana: ")); ?></strong></label>
                                            <input id="txtvaduana" class="form-control form-control-sm ml-2 txtvaduana col-sm-8 col-md-8 col-lg-8" type="text" name="txtvaduana">
                                        </div>
                                    </div>
                                    <div class="form-row pt-2 pb-2">

                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblumedida" class="lbl"><strong><?php echo e(__("UM: ")); ?></strong></label>
                                            <input id="txtumedida" class="form-control form-control-sm ml-2 txtumedida col-sm-8 col-md-8 col-lg-8" type="text" name="txtumedida">
                                        </div>
                                        <div class="form-inline col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                            <label for="lblpesokg" class="lbl"><strong><?php echo e(__("Peso KG: ")); ?></strong></label>
                                            <input id="txtpesokg" class="form-control form-control-sm ml-2 txtpesokg col-sm-8 col-md-8 col-lg-8" type="text" name="txtpesokg">
                                        </div>
                                    </div>
                                </div>
                                <div class="footerproducto mt-1">
                                    <button type="button" id="btn-guardcontinuar" class="btn btn-sm btn-secondary mr-1 rounded btn-guardcontinuar"><?php echo e(__('Agregar y Continuar')); ?></button>
                                    <button type="button" id="btn-guardexit" class="btn btn-sm btn-primary mr-1 rounded btn-guardexit"><?php echo e(__('Guardar y Salir')); ?></button>
                                    <button type="button" id="btn-actproducto" class="btn-actproducto btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                    <button type="button" id="btn-closeproducto" class="btn btn-sm btn-danger rounded btn-closeproducto"><?php echo e(__('Cerrar')); ?></button>
                                </div>

                                <div class="divtableproducto col-sm-12 col-md-12 col-lg-12 col-xl-12 mt-3 p-0">
                                    <table class="table table-hover table-sm table-responsive-sm">
                                        <thead class="thead-primary">
                                            <tr class="justify-content-between">
                                                <th scope="col"  class="bg-light"><?php echo e(__("No")); ?></th>
                                                <th scope="col"  class="bg-light"><?php echo e(__("Descrp")); ?></th>
                                                <th scope="col"  class="bg-light"><?php echo e(__("Articulo")); ?></th>
                                                <th scope="col"  class="bg-light"><?php echo e(__("Cant")); ?></th>
                                                <th scope="col"  class="bg-light"><?php echo e(__("Valor Aduana")); ?></th>
                                                <th scope="col"  class="bg-light"><?php echo e(__("M3")); ?></th>
                                                <th scope="col"  class="bg-light"><?php echo e(__("Peso KG")); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="rowtd">450</td>
                                                <td class="rowtd">MISCELANEA</td>
                                                <td class="rowtd">MISCELANEA</td>
                                                <td class="rowtd">1</td>
                                                <td class="rowtd">0.00</td>
                                                <td class="rowtd">0.45</td>
                                                <td class="rowtd">1.50</td>
                                            </tr>
                                            <tr>
                                                <td class="rowtd">451</td>
                                                <td class="rowtd">MISCELANEA</td>
                                                <td class="rowtd">MISCELANEA</td>
                                                <td class="rowtd">1</td>
                                                <td class="rowtd">0.00</td>
                                                <td class="rowtd">0.50</td>
                                                <td class="rowtd">1.50</td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/m-producto.blade.php ENDPATH**/ ?>