<?php

namespace App\Http\Controllers\BL;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Vawb;
use App\Models\Vbl;
use App\Models\VordenToEmbarque;
use Barryvdh\DomPDF\Facade as PDF;


class BlController extends Controller
{
    //

    public function index(){

        return view('documentacion.panelDocumentacion');
    }

    public function getSolicitudes(Request $request){

        if ($request->isMethod('post')){

            $jsondata=array();
            $jsondata['data'] = Vbl::where('no_embarque','=',$request->noembarque)->get(['noblhouse','shipper','consignee']);

            if($jsondata['data'] == null){
                $jsondata['success'] = false;
                $jsondata['message'] = 'Request made';
                echo json_encode($jsondata);

            }
            else{
                $jsondata['success'] = true;
                $jsondata['message'] = 'Request made';
                echo json_encode($jsondata);

            }
        }
    }

    public function generaBlPdf(Request $request){
        $cadena = explode("+", $request->param);
        $tipobl = "";
        if($cadena[1] == "undefined"){
            $tipobl="COPY";
        }
        else{
            $tipobl = "ORIGINAL";
        }

        // $bls=Vbl::where('noblhouse',$request->param)->get();
        $bls=Vbl::where('noblhouse',$cadena[0])->get();
        $pdf = PDF::loadView('documentacion.bl_newtest',compact(['bls','tipobl']));

        $path = public_path('/pdf');
        $fileName =  $bls[0]->noblhouse.'.pdf' ;

        $pdf->save($path . '/' . $fileName);
        $pdf = public_path('pdf/'.$fileName);

        // $pdf->download($pdf);

        return response()->json([
            'success' => 'false',
            'message'=>'descargado',
            'data' => $bls[0]->noblhouse
        ]);
    }


    public function generaGuiaPdf(Request $request){
        // $cadena = explode("+", $request->param);
        // $tipobl = "";
        // if($cadena[1] == "undefined"){
        //     $tipobl="COPY";
        // }
        // else{
        //     $tipobl = "ORIGINAL";
        // }

        // $bls=Vbl::where('noblhouse',$request->param)->get();
        $awbs=Vawb::where('noawb',$request->param)->get();
        $pdf = PDF::loadView('documentacion.awb3',compact('awbs'));


        $path = public_path('/pdf');
        $fileName =  $awbs[0]->noawb.'.pdf' ;

        $pdf->save($path . '/' . $fileName);
        $pdf = public_path('pdf/'.$fileName);

        // $pdf->download($pdf);

        return response()->json([
            'success' => 'false',
            'message'=>'descargado',
            'data' => $awbs[0]->noawb
        ]);
    }
}
