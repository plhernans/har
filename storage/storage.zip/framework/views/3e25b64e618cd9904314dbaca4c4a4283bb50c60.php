<form id="formBooking" class="formBooking" hidden>
<?php echo csrf_field(); ?>

<?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('booking.findPort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
    <div id="cardbookingnew" class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div id="titleBooking"><?php echo e(__("Booking")); ?></div>
                <button id="btnCloseBooking" type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                </button>
            </div>

        </div>
        <div class="card-body">
            <?php echo $__env->make('partials._formBookingBL', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
</form>
<a id="urlreservaupdate" href="<?php echo e(route('tccliente.update','')); ?>" hidden></a>
<a id="urlgetport" href="<?php echo e(route('tcport.show','')); ?>" hidden></a>
<a id="urlbookingstore" href="<?php echo e(route('booking.store')); ?>" hidden></a>

<!--<a id="urlgetport" href=" route('tcport.show','') }}" hidden></a> -->

<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/booking/bookingnew.blade.php ENDPATH**/ ?>