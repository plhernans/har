

<?php $__env->startSection('content'); ?>
    <form id="faddvessel" name="faddvessel" class="_tcvessels">
        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-6 col-xl-6 m-auto">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Agregar Buque</h3>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-sm-6 mr-4">
                            <label for="lbltcbuque"><?php echo e(__("Nombre del Buque")); ?></label>
                            <input id="tcbuque" class="form-control" type="text" name="tcbuque">
                        </div>
                        <div class="form-group col-sm-5">
                            <label for="lbltcimo"><?php echo e(__("No. Imo")); ?></label>
                            <input id="tcbuqueimo" class="form-control" type="text" name="tcbuqueimo">
                        </div>
                    </div>
                </div>
                <div class="car-footer">
                    <button class="btn btn-primary mb-2" style="align-items: right"><?php echo e(__("Guardar")); ?></button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/partials/tc/_tcvessels.blade.php ENDPATH**/ ?>