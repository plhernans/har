<div class="modal mt-5" id="mAddBuque">
    <div id="mAddBuqueDialog" class="modal-dialog modal-lg-dialog mAddBuque">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formAV" name="faddvessel" class="formAV" method="POST" action="<?php echo e(route('tcvessel.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Agregar Buque</h4>
                                <hr>
                                <div id="fieldTcBuque" class="form-row">
                                    <div class="form-group col-sm-6 mr-4">
                                        <label for="lbltcbuque"><strong><?php echo e(__("Nombre del Buque")); ?></strong></label>
                                        <input id="tcbuque" class="form-control form-control-sm buque" type="text" name="tcbuque" required>
                                    </div>
                                    <div class="form-group col-sm-5">
                                        <label for="lbltcimo"><strong><?php echo e(__("No. Imo")); ?></strong></label>
                                        <input type="text" id="tcbuqueimo" class="form-control form-control-sm noimo" type="text" name="tcbuqueimo" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer ml-auto mr-4">
                                <button id="btnSaveBuque" class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btnClose"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>




<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mAddBuque.blade.php ENDPATH**/ ?>