<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Vawb
 * 
 * @property string $no_embarque
 * @property string $shipper
 * @property string $dirshipper
 * @property string|null $consignee
 * @property string|null $ci
 * @property string $telefono
 * @property string|null $direccion
 * @property string $municipio
 * @property string $provincia
 * @property string $aeronave
 * @property string $vuelo
 * @property string|null $origen
 * @property string|null $destino
 * @property string $nombre
 * @property string $dir
 * @property string|null $contenedor
 * @property string|null $descripcion
 * @property string|null $cantidadpiezas
 * @property float|null $bulto
 * @property float|null $cantidad
 * @property float|null $gross
 * @property float|null $m3
 * @property float|null $precio
 * @property float|null $pagado
 * @property string|null $noawb
 * @property int $idorden
 * @property string|null $estado
 * @property Carbon $fecha
 * @property string $codigoenvio
 * @property string $aerolinea
 *
 * @package App\Models
 */
class Vawb extends Model
{
	protected $table = 'vawb';
	public $incrementing = false;
	public $timestamps = false;

	protected $casts = [
		'bulto' => 'float',
		'cantidad' => 'float',
		'gross' => 'float',
		'm3' => 'float',
		'precio' => 'float',
		'pagado' => 'float',
		'idorden' => 'int'
	];

	protected $dates = [
		'fecha'
	];

	protected $fillable = [
		'no_embarque',
		'shipper',
		'dirshipper',
		'consignee',
		'ci',
		'telefono',
		'direccion',
		'municipio',
		'provincia',
		'aeronave',
		'vuelo',
		'origen',
		'destino',
		'nombre',
		'dir',
		'contenedor',
		'descripcion',
		'cantidadpiezas',
		'bulto',
		'cantidad',
		'gross',
		'm3',
		'precio',
		'pagado',
		'noawb',
		'idorden',
		'estado',
		'fecha',
		'codigoenvio',
		'aerolinea'
	];
}
