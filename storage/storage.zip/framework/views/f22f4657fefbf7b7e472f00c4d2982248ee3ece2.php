<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{ __('Dashboard') }}</div>

                <div class="card-body">
                    if (session('status'))
                        <div class="alert alert-success" role="alert">
                            { session('status') }}
                        </div>
                    endif

                    { __('You are logged in!') }}
                </div>
            </div>
        </div>
    </div>
</div>-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/home.blade.php ENDPATH**/ ?>