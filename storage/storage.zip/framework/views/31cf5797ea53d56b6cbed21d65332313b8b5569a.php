<div class="modal mt-5 fade" id="mCliente">
    <div id="mClienteDialog" class="modal-dialog modal-lg-dialog mCliente">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formCliente" class="formCliente" method="POST" action="<?php echo e(route('tccliente.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <h3><strong><?php echo e(__('Nuevo Cliente')); ?></strong></h3>
                                <hr>
                                <div id="fieldTcCliente" class="form-row">
                                    <div class="form-group col-sm-6 mr-4">
                                        <input id="idcliente" class="form-control form-control-sm idcliente" type="text" hidden disabled>
                                    </div>
                                    <div class="form-group col-sm-5 mr-4"></div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblcliente"><strong><?php echo e(__("Cliente o Proveedor")); ?></strong></label>
                                        <input type="text" id="clientename" class="form-control form-control-sm clientename" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lbladdress"><strong><?php echo e(__("Direccion")); ?></strong></label>
                                        <textarea row="5" id="clientedir" class="form-control form-control-sm clientedir" placeholder="Eg: Calle miranda, no.1" required></textarea>
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="lbladdress"><strong><?php echo e(__("Codigo Postal")); ?></strong></label>
                                        <input type="number" id="clientezp" class="form-control form-control-sm clientezp" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer ml-auto mr-4">
                                <button id="btnSaveCliente" class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btnUpdateCliente" class="btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btnCloseCliente"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlclienteupdate" href="<?php echo e(route('tccliente.update','')); ?>" hidden></a>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mCliente.blade.php ENDPATH**/ ?>