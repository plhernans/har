<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('embarques.listadoembarque', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('embarques.embarquedetalle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('embarques.ordendetalle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/embarques/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/embarques/crearEmbarque.js')); ?>"></script>
    <script src="<?php echo e(asset('js/embarques/obtenerEmbarque.js')); ?>"></script>
    <script src="<?php echo e(asset('js/embarques/actualizaEmbarque.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/maritimo.blade.php ENDPATH**/ ?>