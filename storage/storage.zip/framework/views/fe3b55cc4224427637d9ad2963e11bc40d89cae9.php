<div class="modal fade" id="modalSuccess">
  <div class="modal-dialog">
    <div class="modal-content" id="modalSuccessContent">

      <!-- Modal Header -->
      <div class="modal-header bg-primary">
        <h4 id="msgtitle" class="modal-title text-white"></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="row modal-body">

        <div class="col-12">
          <span id="msgerror"></span>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button id="btnModalSuccess" type="button" class="btn btn-primary" data-dismiss="modal">Done</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/modalSuccess.blade.php ENDPATH**/ ?>