<div class="modal mt-5 fade" id="mGoods">
    <div id="mGoodsDialog" class="modal-dialog modal-lg-dialog mGoods">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/Tc/tcstyle.css')); ?>" rel="stylesheet">
           <!-- <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet"> -->

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formGoods" class="formGoods" method="POST" action="<?php echo e(route('tcgoods.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <div id="fieldTcGoods" class="form-row">
                                    <div class="form-group col-sm-12 mr-4">
                                        <input id="idgoods" class="form-control form-control-sm idgoods" type="text" hidden>
                                    </div>
                                    <div class="form-group col-sm-12 mr-4">
                                        <label for="lblgoodsdescr"><strong><?php echo e(__("Type of Goods")); ?></strong></label>
                                        <input id="txtgoodsdescr" class="form-control form-control-sm txtgoodsdescr" type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer ml-auto mr-4">
                                <button id="btnSaveGoods" class="btn btn-sm btn-primary mb-2 btnSaveGoods"><?php echo e(__("Save")); ?></button>
                                <button id="btnUpdateGoods" class="btn btn-sm btn-outline-primary mb-2 btnUpdateGoods" hidden><?php echo e(__("Update")); ?></button>
                                <button id="btnCloseGoods" type="button" class="btn btn-sm btn-danger mb-2 btnCloseGoods"><?php echo e(__("Close")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlgoodsupdate" href="<?php echo e(route('tcgoods.update','')); ?>" hidden></a>
            </div>

        </div>
    </div>
</div>




<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mGoods.blade.php ENDPATH**/ ?>