

<?php $__env->startSection('content'); ?>
    <div id="tcontrol" class="container-fluid bg-light">
       <!-- <div id="tcmenuleft" class="col-2 col-lg-2">
            <h5 id="tc-title">Tablas de Control</h5>
            <div class="col-12 py-1">
                <button class="btn btn-primary rounded btnports">{ __('Puertos')}}</button>
            </div>
            <div class="col-12 py-1">
                <button class="btn btn-primary rounded btnguests">{ __("Clientes") }}</button>
            </div>
            <div class="col-12 py-1 pl-3 pr-0">
                <button class="btn btn-primary rounded">{ __("Cond. Entrega") }}</button>
            </div>
            <div class="col-12 py-1">
                <button class="btn btn-primary rounded">{ __("Contenedores") }}</button>
            </div> 
        </div>-->
            
        <div>
            <?php echo $__env->yieldContent('tccontent'); ?>
        </div>
        <!-- include('partials/tc._tcvessels') -->
        <!-- include('partials/tc._tcguests') -->
        <!--('partials/tc._tcports') -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tcontrol/tcontrol.blade.php ENDPATH**/ ?>