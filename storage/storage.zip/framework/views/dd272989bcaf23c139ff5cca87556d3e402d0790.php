

<?php $__env->startSection('content'); ?>
    <div id="conttc" class="container-fluid row">
        <div id="tcmenuleft" class="col-2 col-lg-2">
            <h5 id="tc-title">Tablas de Control</h5>
            <div class="col-12 py-1">
                <button class="btn btn-primary rounded btnports"><?php echo e(__('Puertos')); ?></button>
            </div>
            <div class="col-12 py-1">
                <button class="btn btn-primary rounded btnguests"><?php echo e(__("Clientes")); ?></button>
            </div>
            <div class="col-12 py-1 pl-3 pr-0">
                <button class="btn btn-primary rounded"><?php echo e(__("Cond. Entrega")); ?></button>
            </div>
            <div class="col-12 py-1">
                <button class="btn btn-primary rounded"><?php echo e(__("Contenedores")); ?></button>
            </div>
            
        </div>
        <div id="tcdatoright" class="col-10 col-lg-10">
            <?php echo $__env->make('partials/tc._tcguests', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials/tc._tcports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/admin/tcontrol.blade.php ENDPATH**/ ?>