    <div class="embarque-principal col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php echo $__env->make('embarques.m-embarque', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('embarques.findPort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="div-mbody col-sm-12 col-md-12 col-lg-12 col-xl-12">

            <div class="col-12">
                <div class="div-mtop d-flex justify-content-between align-items-center">
                    <h4><?php echo e(__("Lista de Embarques")); ?></h4>
                    <button type="button" class="btn-nuevoembarq btn btn-sm btn-secondary rounded ml-auto "><?php echo e(__("Crear Embarque")); ?>

                    </button>
                    <input type="text"
                            id="user"
                            name="user"
                            class="form-control"
                            value="<?php echo e(Auth()->user()->id); ?>"
                            disabled
                            readonly
                            hidden>
                </div>
                <table class="table table-hover table-sm table-responsive-sm tablelistadoembarque">
                    <thead class="thead-light">
                        <tr class="justify-content-between">
                            <th scope="col"  class="bg-light"><?php echo e(__("No.Embarque")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Origen")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Tipo Embarque")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Buque")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Viaje")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Pol")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Pod")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Embarcador")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Cosnigando")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("ETS")); ?></th>
                            <th scope="col"  class="bg-light" style="text-align: center"><?php echo e(__("Accion")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("Cod_Origen")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("Cod_Emb")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("TipoCont")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("Cont")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("P_Bruto")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("P_Neto")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("Tara")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("idpol")); ?></th>
                            <th scope="col"  class="bg-light" hidden><?php echo e(__("idpod")); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $vembarques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vembarqueitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-no_embarque="<?php echo e($vembarqueitem->no_embarque); ?>" data-origen="<?php echo e($vembarqueitem->origen); ?>" data-tipoembarque="<?php echo e($vembarqueitem->tipoembarque); ?>" data-buque="<?php echo e($vembarqueitem->buque); ?>" data-viaje="<?php echo e($vembarqueitem->viaje); ?>" data-embarcador="<?php echo e($vembarqueitem->embarcador); ?>" data-consignado="<?php echo e($vembarqueitem->consignado); ?>" data-pol="<?php echo e($vembarqueitem->pol); ?>" data-pod="<?php echo e($vembarqueitem->pod); ?>" data-tipocont="<?php echo e($vembarqueitem->tipocont); ?>" data-contenedor="<?php echo e($vembarqueitem->contenedor); ?>" data-p_bruto="<?php echo e($vembarqueitem->p_bruto); ?>" data-p_neto="<?php echo e($vembarqueitem->p_neto); ?>" data-tara="<?php echo e($vembarqueitem->tara); ?>" data-fecha_est="<?php echo e($vembarqueitem->fecha_est); ?>" data-idpol="<?php echo e($vembarqueitem->idpol); ?>" data-idpod="<?php echo e($vembarqueitem->idpod); ?>" data-codigoorigen="<?php echo e($vembarqueitem->codigoorigen); ?>" data-codigoembarque="<?php echo e($vembarqueitem->codigoembarque); ?>">
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->no_embarque); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->origen); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->tipoembarque); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->buque); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->viaje); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->pol); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->pod); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->embarcador); ?></td>
                            <td class="rowtdembarque"><?php echo e($vembarqueitem->consignado); ?></td>
                            <td class="rowtdembarque"><?php echo e(Str::limit($vembarqueitem->fecha_est, 10)); ?></td>
                            <td class="rowtdembarque" style="text-align: center">
                                    <button class="btn btn-sm btn-secondary mr-auto btn-editarembarque"><?php echo e(__('Editar')); ?></button>
                                    <button class="btn btn-sm btn-danger mr-auto btn-cancelarembarque"><?php echo e(__('Cancelar')); ?></button>
                            </td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->codigoorigen); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->codigoembarque); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->tipocont); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->contenedor); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->p_bruto); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->p_neto); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->tara); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->idpol); ?></td>
                            <td class="rowtdembarque" hidden><?php echo e($vembarqueitem->idpod); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/listadoembarque.blade.php ENDPATH**/ ?>