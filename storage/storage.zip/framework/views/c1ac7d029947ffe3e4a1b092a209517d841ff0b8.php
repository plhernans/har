<div class="modal mt-5 fade" id="mBuque">
    <div id="mBuqueDialog" class="modal-dialog modal-lg-dialog mBuque">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formAV" class="formAV" method="POST" action="<?php echo e(route('tcvessel.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <h3><strong><?php echo e(__('Agregar Buque')); ?></strong></h3>
                                <hr>
                                <div id="fieldTcBuque" class="form-row">
                                    <div class="form-group col-sm-6 mr-4">
                                        <input id="idbuque" class="form-control form-control-sm idbuque" type="text" name="idbuque" hidden>
                                    </div>
                                    <div class="form-group col-sm-6 mr-4">
                                        <label for="lbltcbuque"><strong><?php echo e(__("Nombre del Buque")); ?></strong></label>
                                        <input id="tcbuque" class="form-control form-control-sm buque" type="text" name="tcbuque" required>
                                    </div>
                                    <div class="form-group col-sm-5">
                                        <label for="lbltcimo"><strong><?php echo e(__("No. Imo")); ?></strong></label>
                                        <input type="text" id="tcbuqueimo" class="form-control form-control-sm noimo" type="text" name="tcbuqueimo" required>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer ml-auto mr-4">
                                <button id="btnSaveBuque" class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btnUpdateBuque" class="btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btnCloseBuque"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlbuqueupdate" href="<?php echo e(route('tcvessel.update','')); ?>" hidden></a>
            </div>

        </div>
    </div>
</div>




<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mBuque.blade.php ENDPATH**/ ?>