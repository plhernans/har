<div class="modal mt-5 fade" id="mNewCont">
    <div id="mNewContDialog" class="modal-dialog modal-lg-dialog mNewCont">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <?php $typeconts = app('App\Services\TypeCont'); ?>
            <?php $typegoods = app('App\Services\TypeGoods'); ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formmNewCont" class="formmNewCont">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card ">

                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div id="titleBooking"><?php echo e(__("New Container")); ?></div>
                                </div>
                            </div>

                            <div class="card-body">
                                <div id="fieldNewCont" class="form-row">
                                    <div class="form-group col-sm-5 mr-4">
                                        <label for="lblbkcont"><strong><?php echo e(__("Container Number")); ?></strong></label>
                                        <input id="txtbkCont" type="text" class="form-control form-control-sm txtbkCont">
                                    </div>
                                    <div class="form-group col-sm-5">
                                        <label for="lblbktypecont"><strong><?php echo e(__("Type of Container")); ?></strong></label>
                                        <select id="txtbktypecont"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txtbktypecont"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $typeconts->getTypeCont(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typecont=>$description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($typecont); ?>" value="<?php echo e($typecont); ?>"> <?php echo e($typecont.' - '.$description); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                    <div class="form-group col-sm-5 mr-4">
                                        <label for="lblbktara"><strong><?php echo e(__("Tara")); ?></strong></label>
                                        <input id="txtbktara" class="form-control form-control-sm txtbktara" type="text" required>
                                    </div>
                                    <div class="form-group col-sm-5">
                                        <label for="lblbkdescr"><strong><?php echo e(__("Type of Goods")); ?></strong></label>
                                        <select id="txtbkgooddescr"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txtbkgooddescr"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $typegoods->getTypeGoods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typegood=>$description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($typegood); ?>" value="<?php echo e($typegood); ?>"> <?php echo e($description); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-5 mr-4">
                                        <label for="lblbkgross"><strong><?php echo e(__("Gross Weight")); ?></strong></label>
                                        <input type="text" id="txtbkgross" class="form-control form-control-sm txtbkgross" type="text" required>
                                    </div>
                                    <div class="form-group col-sm-5">
                                        <label for="lblbkseals"><strong><?php echo e(__("Seals")); ?></strong></label>
                                        <input type="text" id="txtbkseals" class="form-control form-control-sm txtbkseals" type="text" required>
                                    </div>

                                </div>
                            </div>
                            <div class="car-footer ml-auto mr-4">
                                <button type="button" class="btn btn-sm btn-primary mb-2 abtnbkAddCont"><?php echo e(__("Add")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 abtnbkCloseAddCont"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/booking/mNewContainer.blade.php ENDPATH**/ ?>