<?php $__env->startSection('content'); ?>


<div class="col-xs-12 col-sm-12 col-md-10 col-lg-6 col-xl-6 m-auto rounded">
    <div class="card">
        <div class="card-body">
            <h3 class="card-title"><?php echo e(__("Listado de Puertos")); ?></h3>
            <hr>


            <button id="btnNewPort" type="button" class="btn btn-sm btn-success rounded mr-auto btnNewPort mb-2"><?php echo e(__("Agregar")); ?>

            </button>
            <button id="btnListadoPort" type="button" class="btn btn-sm btn-success rounded mr-auto btnListadoPort mb-2"><?php echo e(__("Listado de Puertos")); ?>

            </button>
            <div class="table-responsive _tcports" style="height: 200px; display: block">
                <div class="d-flex justify-content-between align-items-center">


                    <input type="text"
                            id="user"
                            name="user"
                            class="form-control"
                            value="<?php echo e(Auth()->user()->id); ?>"
                            disabled
                            readonly
                            hidden>
                </div>
                <table class="table table-hover table-sm table-responsive-sm tableport">
                    <thead class="thead-light">
                    <!-- <tr>
                        <th class="bg-secondary" colspan="10">
                        <button id="btnChdeckin" type="button" class="btn btn-sm btn-outline-warning rounded mr-auto" disabled=""> __("Check-in")
                            </button>
                            <button id="btnDeldeteBooking" type="button" class="btn btn-sm btn-danger rounded mr-auto" disabled=""> __("Cancel Booking")
                            </button>
                        </th> -->
                    </tr>
                    <tr class="trheader_tcports">
                        <!--<th></th> -->
                        <th scope="col"  class="bg-light trheader_tcports"><?php echo e(__("Pais")); ?></th>
                        <th scope="col"  class="bg-light trheader_tcports"><?php echo e(__("Puerto")); ?></th>
                        <th scope="col"  class="bg-light trheader_tcports"><?php echo e(__("Codigo")); ?></th>
                        <th class="bg-light thsearch"><input id="searchport" type="search"></th>
                    </tr>
                    </thead>
                    <tbody id="tbodytcport">
                        <?php $__empty_1 = true; $__currentLoopData = $tcport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>
                            <!-- <td><input type="radio" class="select item-radiobutton" name="check" value=" $bitem->id "></td> -->
                                <td id="name" class="rowtd tdcountry"><?php echo e($row->country); ?></td>
                                <td class="rowtd tdport"><?php echo e($row->port); ?></td>
                                <td class="rowtd tdcode"><?php echo e($row->code); ?></td>
                                <td class="rowtd tdbtnport">
                                    <button type="button" class="btn btn-sm btn-outline-secondary rounded"><?php echo e(__("Actualizar")); ?>

                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger rounded btnDeleteBooking"><?php echo e(__("Eliminar")); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="bg-dark text-warning"><?php echo e(__("No hay datos que mostrar")); ?></p>
                        <?php endif; ?>

                        <!-- URL para obtener el booking -->
                    <!--<a id="url" hidden href=" { route('vbooking.show','')}}"> </a>  -->
                    </tbody>
                    <div>
                        <?php echo e($tcport->links()); ?>

                    </div>
                </table>
            </div>
            <div class="col-*-12 formpuerto" style="display: none">
                <form id="formpuerto" name="formpuerto" class="formpuerto col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12">
                    <div class="col-*-12 m-auto">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title"><?php echo e(__("Agregar un Puerto")); ?></h3>
                                <hr>
                                <div class="form-row">
                                    <div class="form-group col-sm-12 mr-4">
                                        <label for="lblpais"><?php echo e(__("Pais")); ?></label>
                                        <input class="form-control" type="text">
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblpuerto"><?php echo e(__("Puerto")); ?></label>
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblcodigo"><?php echo e(__("Codigo")); ?></label>
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer mr-4 ml-auto">
                                <button class="btn btn-primary mb-2 "><?php echo e(__("Guardar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
           <!-- <div class="car-footer">
                <div class="justify-content-between align-items-right">
                    <button class="btn btn-sm btn-primary">{ __("Guardar") }}</button>
                </div>

            </div>-->
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/partials/tc/_tcports.blade.php ENDPATH**/ ?>