<div id="cardlistbill" class="card">
    <div class="card-header bg-light pt-1" style="height: 30px">
        <label style="font-size: 15px"><?php echo e(__('List of Bill of Lading')); ?></label>
    </div>
    <div class="card-header bg-default pt-1" style="height: 34px">
        <div class="row">
            <div class="p-0" style="font-size: 14px"><button class="btn btn-sm btn-outline-dark"><?php echo e(__('Edit Bill')); ?></button></div>
            <div class="ml-1 p-0" style="font-size: 14px"><button class="btn btn-sm btn-outline-danger"><?php echo e(__('Delete Bill')); ?></button></div>
        </div>

    </div>
    <div class="card-body cardbodyListBill pt-1 px-0">
        <table class="table table-hover table-sm">
            <thead class="thead bg-light">
                <tr>
                    <th><input type="checkbox"></td>
                    <th><?php echo e(__('Vessel')); ?></td>
                    <th><?php echo e(__('Voyage')); ?></td>
                    <th><?php echo e(__('No. Booking')); ?></td>
                    <th><?php echo e(__('Shipper')); ?></td>
                    <th><?php echo e(__('No. BL')); ?></td>
                    <th><?php echo e(__('Status')); ?></td>
                    <th><?php echo e(__('Date')); ?></td>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $vbill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vbillitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-vessel="<?php echo e($vbillitem->vessel); ?>" data-voyage="<?php echo e($vbillitem->voyage); ?>" data-nobooking="<?php echo e($vbillitem->nobooking); ?>" data-shipper="<?php echo e($vbillitem->shipper); ?>" data-bl="<?php echo e($vbillitem->bl); ?>" data-created_at="<?php echo e($vbillitem->created_at); ?>">
                        <td><input type="checkbox"></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->vessel); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->voyage); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->nobooking); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->shipper); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->bl); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->bl ? 'CONFIRM':'PENDANT'); ?></td>
                        <td class="rowtdbooking"><?php echo e($vbillitem->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/billoflading/billList.blade.php ENDPATH**/ ?>