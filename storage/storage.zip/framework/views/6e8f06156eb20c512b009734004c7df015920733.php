<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('modals.mViaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 mx-auto px-2 rounded">
        <table id="tableViajeBuque" class="col-12 col-lg-12 table table-bordered table-sm">
            <thead class="thead-light">
                <tr>
                    <button id="btnAddViaje" class="btn btn-sm btn-outline-primary btnAddViaje mb-1"><?php echo e(__("Agregar Viaje")); ?></button>
                </tr>
                <tr class="justify-content-between">
                    <th scope="col" hidden><?php echo e(__("idv")); ?></th>
                    <th scope="col" hidden><?php echo e(__("idb")); ?></th>
                    <th scope="col"><?php echo e(__("Nombre Buque.")); ?></th>
                    <th scope="col"><?php echo e(__("Viaje")); ?></th>
                    <th scope="col" colspan="2" style="text-align: center"></th>
                </tr>
            </thead>
            <tbody id="tableViajeBody">
                <?php $__currentLoopData = $vbuqueviaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buqueviajeitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-idviaje="<?php echo e($buqueviajeitem->idviaje); ?>" data-idbuque="<?php echo e($buqueviajeitem->idbuque); ?>" data-buque="<?php echo e($buqueviajeitem->buque); ?>" data-viaje="<?php echo e($buqueviajeitem->viaje); ?>">
                        <td class="rowtdbuque" hidden><?php echo e($buqueviajeitem->idviaje); ?></td>
                        <td class="rowtdbuque" hidden><?php echo e($buqueviajeitem->idbuque); ?></td>
                        <td class="rowtdbuque"><?php echo e($buqueviajeitem->buque); ?></td>
                        <td class="rowtdbuque"><?php echo e($buqueviajeitem->viaje); ?></td>
                        <td><button class="btn btn-sm btn-warning btnEditarViaje">Editar</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Viaje/CreaViaje.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Viaje/ActualizaViaje.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/viaje/frameViaje.blade.php ENDPATH**/ ?>