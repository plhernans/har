<?php $origenes = app('App\Services\Origenes'); ?>
<?php $embarques = app('App\Services\TipoEmbarques'); ?>
<?php $customers = app('App\Services\Customers'); ?>
<?php $paises = app('App\Services\Paises'); ?>
<?php $delivery = app('App\Services\Delivery'); ?>

<div id="billofladingNew" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0" hidden>
    <form id="formBill" class="formBill">
        <?php echo csrf_field(); ?>

        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <div id="titleBill"><?php echo e(__("Bill of Lading")); ?></div> <div id="bookingNo" class="ml-auto noReserva"></div>
                    </div>

                </div>
                <div class="card-body">
                    <?php echo $__env->make('partials._formBookingBL', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </form>
    <a id="urlgetport" href="<?php echo e(route('tcport.show','')); ?>" hidden></a>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/billoflading/billoflading.blade.php ENDPATH**/ ?>