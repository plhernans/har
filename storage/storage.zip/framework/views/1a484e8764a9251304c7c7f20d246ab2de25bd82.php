<?php $origenes = app('App\Services\Origenes'); ?>
<?php $embarques = app('App\Services\TipoEmbarques'); ?>
<?php $clientes = app('App\Services\Clientes'); ?>
<?php $paises = app('App\Services\Paises'); ?>
<?php $typeconts = app('App\Services\TypeCont'); ?>
<?php $buques = app('App\Services\SVBuqueViaje'); ?>

<div class="modal mt-5 fade" id="m-embarque">
    <div id="m-mbarqueDialog" class="modal-dialog modal-lg-dialog m-embarque">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formEmbarque" class="formEmbarque" method="POST" action="<?php echo e(route('maritimo.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card contenedor-membarque">
                            <div class="card-body">
                                <h3 id="title-membarque"><strong><?php echo e(__('Nuevo Embarque')); ?></strong></h3>
                                <hr>
                                <div class="form-row pt-2">
                                    <div class="form-group col-sm-4">
                                        <input id="txtembarque" class="form-control form-control-sm txtembarque" type="text" name="txtembarque" hidden disabled>
                                    </div>
                                </div>
                                <div id="fielddg" class="form-row pt-2">
                                    <div class="form-group col-sm-4">
                                        <label for="lblorigen"><strong><?php echo e(__("Pais de Solicitud")); ?></strong></label>
                                        <select id="txtorigen"
                                                name="txtorigen"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txtorigen"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $origenes->getOrigenes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo=>$origen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($origen); ?>" value="<?php echo e($origen); ?>"> <?php echo e($origen); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="lblembarcador"><strong><?php echo e(__("Embarcador")); ?></strong></label>
                                        <select id="txtembarcador"
                                                name="txtembarcador"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txtembarcador"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $clientes->getClientes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($nombre); ?>" value="<?php echo e($nombre); ?>"> <?php echo e($nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblconsignado"><strong><?php echo e(__("Consignado")); ?></strong></label>
                                        <select id="txtconsignado"
                                                name="txtconsignado"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txtconsignado"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $clientes->getClientes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($nombre); ?>" value="<?php echo e($nombre); ?>"> <?php echo e($nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="lbltipoemb"><strong><?php echo e(__("Tipo de Embarque")); ?></strong></label>
                                        <select id="txttipoemb"
                                                name="txttipoemb"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txttipoemb"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $embarques->getTipoEmbarques(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo=>$embarque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($codigo); ?>" value="<?php echo e($codigo); ?>"> <?php echo e($embarque); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblbuque"><strong><?php echo e(__("Buque")); ?></strong></label>
                                        <select id="txtbuque" name="txtbuque" class="selectpicker show-menu-arrow form-control form-control-sm txtbuque" data-live-search="true" disabled>
                                            <?php $__currentLoopData = $buques->getBuques(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idbuque=>$buque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($idbuque); ?>" value="<?php echo e($idbuque); ?>"> <?php echo e($buque); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblviaje"><strong><?php echo e(__("Viaje")); ?></strong></label>
                                        <select id="txtviaje" name="txtviaje" class="selectpicker show-menu-arrow form-control form-control-sm txtviaje" data-live-search="true" disabled>

                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblfechaest"><strong><?php echo e(__("Fecha Est.")); ?></strong></label>
                                        <input id="txtfechaest" class="form-control form-control-sm txtfechaest" type="date" name="txtfechaest" disabled>
                                        <div class="valid-feedback">Valid.</div>
                                        <div class="invalid-feedback">Please fill out this field.</div>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpol"><strong><?php echo e(__("POL")); ?></strong></label>
                                        <input id="txtpol" class="form-control form-control-sm txtpol" type="text" name="txtpol" disabled>
                                        <input id="idtxtpol" class="form-control form-control-sm idtxtpol" type="text" name="idtxtpol" hidden disabled>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpod"><strong><?php echo e(__("POD")); ?></strong></label>
                                        <input id="txtpod" class="form-control form-control-sm txtpod" type="text" name="txtpod" disabled>
                                        <input id="idtxtpod" class="form-control form-control-sm idtxtpod" type="text" name="idtxtpod" hidden disabled>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lbltipocont"><strong><?php echo e(__("Tipo Cont")); ?></strong></label>
                                        <select id="txttipocont"
                                                name="txttipocont"
                                                class="selectpicker show-menu-arrow form-control form-control-sm txttipocont"
                                                data-live-search="true" disabled>
                                            <?php $__currentLoopData = $typeconts->getTypeCont(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typecont=>$description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($typecont); ?>" value="<?php echo e($typecont); ?>"> <?php echo e($typecont.' - '.$description); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblcont"><strong><?php echo e(__("No. Cont")); ?></strong></label>
                                        <input id="txtcont" class="form-control form-control-sm txtcont" type="text" name="txtcont" disabled>
                                    </div>

                                    <div class="form-group col-sm-4">
                                        <label for="lbltara"><strong><?php echo e(__("Tara")); ?></strong></label>
                                        <input id="txttara" class="form-control form-control-sm txttara" type="text" name="txttara" disabled>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpesob"><strong><?php echo e(__("Peso Bruto")); ?></strong></label>
                                        <input id="txtpesob" class="form-control form-control-sm txtpesob" type="text" name="txtpesob" disabled>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="lblpeson"><strong><?php echo e(__("Peso Neto")); ?></strong></label>
                                        <input id="txtpeson" class="form-control form-control-sm txtpeson" type="text" name="txtpeson" disabled>
                                    </div>

                                </div>
                            </div>
                            <div class="card-footer ml-auto mr-4">
                                <button type="button" id="btn-guardaembarque" class="btn btn-sm btn-primary mb-2 btn-guardaembarque"><?php echo e(__("Guardar")); ?></button>
                                <button type="button" id="btn-actembarque" class="btn btn-sm btn-outline-primary mb-2 btn-actembarque" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" id="btn-closeembarque" class="btn btn-sm btn-danger mb-2 btn-closeembarque"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlembarqueupdate" href="<?php echo e(route('maritimo.update','')); ?>" hidden></a>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/m-embarque.blade.php ENDPATH**/ ?>