<?php $__env->startSection('content'); ?>
    <div class="tablacontrol-buque col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php echo $__env->make('modals.mBuque', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="div-mbody col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="col-12">
                <table id="tableTcBuque" class="col-12 col-lg-12 table table-hover table-sm">
                    <thead class="thead-light">
                        <tr>
                            <button id="btnAddBuque" class="btn btn-sm btn-outline-primary btnAddBuque mb-1"><?php echo e(__("Agregar Buque")); ?></button>
                        </tr>
                        <tr class="justify-content-between">
                            <th scope="col" hidden><?php echo e(__("No.")); ?></th>
                            <th scope="col"><?php echo e(__("Nombre Buque.")); ?></th>
                            <th scope="col"><?php echo e(__("No. IMO.")); ?></th>
                            <th scope="col" colspan="2" style="text-align: center"></th>
                        </tr>
                    </thead>
                    <tbody id="tableTcBuqueBody">
                        <?php $__currentLoopData = $tcbuque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buqueitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-idvessel="<?php echo e($buqueitem->idvessel); ?>" data-name="<?php echo e($buqueitem->name); ?>" data-noimo="<?php echo e($buqueitem->noimo); ?>">
                                <td class="rowtdbuque" hidden><?php echo e($buqueitem->idvessel); ?></td>
                                <td class="rowtdbuque"><?php echo e($buqueitem->name); ?></td>
                                <td class="rowtdbuque"><?php echo e($buqueitem->noimo); ?></td>
                                <td class="col-1" style="text-align: center"><button class="btn btn-sm btn-secondary btnEditarBuque"><?php echo e(__("Editar")); ?></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Tc/CreaTcBuque.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Tc/ActualizaTcBuque.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/_tcbuque.blade.php ENDPATH**/ ?>