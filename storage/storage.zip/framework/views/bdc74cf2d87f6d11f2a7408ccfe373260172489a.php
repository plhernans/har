<?php $__env->startSection('content'); ?>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
    <div class="card">

        <div class="card-header bg-primary text-white pt-1" style="height: 30px">
            <div style="font-size: 15px"><strong><?php echo e(__('Bill of Lading')); ?></strong></div>
        </div>
        <div class="card-header bg-light pt-1 pb-1" style="height: 35px">
            <button class="btn btn-dark btn-sm btnPanelNewBill" style="font-size: 12px"><?php echo e(__('Create Bill')); ?></button>
        </div>

        <div class="card-body cardbodyPanelBill">
            <?php echo $__env->make('modals.mFromBooking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('billoflading.mGoodsbl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('billoflading.billList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('billoflading.billoflading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="card-footer p-1 d-flex justify-content-between">
        <!-- <div class="btn-group ml-auto"> -->
             <button id="btnSaveBill" type="button" class="btn btn-sm btn-primary mb-1 mr-1" hidden><?php echo e(__("Save Bill")); ?></button>
             <button id="btnUpdateBill" type="button" class="btn btn-sm btn-outline-primary mb-1 mr-1" hidden><?php echo e(__("Update")); ?></button>
         <!--v</div> -->
     </div>
</div>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Bill/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Bill/getBooking.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Bill/CreateBill.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/billoflading/panelBl.blade.php ENDPATH**/ ?>