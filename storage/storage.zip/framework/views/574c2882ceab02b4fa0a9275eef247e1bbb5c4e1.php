    <div class="orden-datalle col-sm-12 col-md-12 col-lg-12 col-xl-12" hidden>
        <?php echo $__env->make('embarques.m-producto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="div-mbody-detalle col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

            <div class="col-12 p-2">
                <div class="col-12 div-mdetalle pl-0">
                    <h4><?php echo e(__('Ordenes - Detalles')); ?></h4>
                    <br>

                    <div class="row d-flex justify-content-between align-items-center ">
                        <h6 class="ml-4"><?php echo e(__('No. Embarque:')); ?></h6> <label class="lblnoembarque-detalle ml-2 mt-1" for="noembarque"></label>
                        <br>
                        <h5 class="ml-4"><?php echo e(__('No. Orden:')); ?></h5> <label class="lblnoorden-detalle ml-2 mt-1" for="noorden">ENV0001-2021 / PEDRO LUIS HERNANDEZ SAUMELL</label>
                        <button type="button" class="btn-nuevoproducto btn btn-sm btn-primary rounded ml-auto "><?php echo e(__("Agregar Producto")); ?></button>
                    </div>


                </div>

                <table class="table table-hover table-sm table-responsive-sm">
                    <thead class="thead-light">
                        <tr class="justify-content-between">
                            <th scope="col"  class="bg-light"><?php echo e(__("Producto   ")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Fecha")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Cant. Bultos")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("M3")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("UM")); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="rowtd">MISCELANEA</td>
                            <td class="rowtd">25-09-2021</td>
                            <td class="rowtd">25</td>
                            <td class="rowtd">12</td>
                            <td class="rowtd">UNIDAD</td>
                        </tr>
                        <tr>
                            <td class="rowtd">MISCELANEA</td>
                            <td class="rowtd">26-09-2021</td>
                            <td class="rowtd">15</td>
                            <td class="rowtd">5</td>
                            <td class="rowtd">UNIDAD</td>

                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
        <div class="row d-flex justify-content-between align-items-center mr-2">
            <button class="btn btn-sm btn-danger ml-auto btncerrar-ordendetalle"><?php echo e(__("Cerrar")); ?></button>
        </div>
    </div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/ordendetalle.blade.php ENDPATH**/ ?>