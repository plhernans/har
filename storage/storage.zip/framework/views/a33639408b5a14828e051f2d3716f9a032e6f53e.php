<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('tc._tccontenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Tc/CreaTcCont.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Tc/ActualizaTcCont.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/tc/tcprincipal.blade.php ENDPATH**/ ?>