<!--if(session('status')) @-->
	<div class="container col-md-12 msgsession my-2" hidden>
		<div class="alert alert-danger alert-dismissible fade show msg" role="alert">
			<button type="button"
					class="close"
					data-dismiss="alert"
					aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	</div>
<!--endif-->
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/partials/_session-msg.blade.php ENDPATH**/ ?>