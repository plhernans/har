<div class="modal mt-5 fade" id="mTipoCont">
    <div id="mTipoContDialog" class="modal-dialog modal-lg-dialog mTipoCont">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formTipoCont" class="formTipoCont" method="POST" action="<?php echo e(route('tccont.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <h3><strong><?php echo e(__('Agregar tipo contenedor')); ?></strong></h3>
                                <hr>
                                <div class="form-row">
                                    <input type="text" id="idtipocont" class="form-control idtipocont" name="idtipocont" required disabled hidden>
                                    <div class="form-group col-sm-12">
                                        <label for="lbltipocont"><strong><?php echo e(__("Tipo Contenedor")); ?></strong></label>
                                        <input type="text" id="txttipocont" class="form-control txttipocont" name="txttipocont" required>
                                    </div>

                                </div>
                                <div class="form row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblTipoContDescripcion"><strong><?php echo e(__("Descripcion")); ?></strong></label>
                                        <input type="text" id="txttipocontdescripcion" class="form-control txttipocontdescripcion" name="txttipocontdescripcion" required>
                                    </div>
                                </div>
                                <div class="form row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblteus"><strong><?php echo e(__("Teus")); ?></strong></label>
                                        <input type="text" id="txtteus" class="form-control txtteus" name="txtteus" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer ml-auto mr-4">
                                <button id="btnSaveCont" class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btnUpdateCont" class="btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btnCloseCont"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlcontupdate" href="<?php echo e(route('tccont.update','')); ?>" hidden></a>
            </div>

        </div>
    </div>
</div>




<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mTipoCont.blade.php ENDPATH**/ ?>