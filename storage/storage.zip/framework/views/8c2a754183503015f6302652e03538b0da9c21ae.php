<div class="modal mt-5 fade" id="mContenedor">
    <div id="mContenedorDialog" class="modal-dialog modal-lg-dialog mContenedor">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formCont" class="formCont" lass="formCont" method="POST" action="<?php echo e(route('tccont.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">

                                <input type="text"
                                    class="form-control id"
                                    disabled
                                    readonly
                                    hidden>
                                <div class="form-row">
                                    <div class="form-group col-sm-12 mr-4">
                                        <label for="lbltipocont"><strong><?php echo e(__("Tipo Contendor")); ?></strong></label>
                                        <input id="txttipocont" name="txttipocont"  class="form-control form-control-sm tipcont" type="text" required>
                                    </div>

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lbldesctipocont"><strong><?php echo e(__("Descripcion")); ?></strong></label>
                                        <input id="txtdescripcion" name="txtdescripcion" class="form-control form-control-sm" type="text" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-sm-12">
                                        <label for="lblcodigo"><strong><?php echo e(__("Teus")); ?></strong></label>
                                        <input id="txtteus" name="txtteus" class="form-control form-control-sm" type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer mr-4 ml-auto">
                                <button id="btnSaveCont" type="button" class="btn btn-sm btn-outline-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btnUpdateCont" type="button" class="btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btnCloseCont"><?php echo e(__("Cancelar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlcontupdate" href="<?php echo e(route('tccont.update','')); ?>" hidden></a>

            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mContenedor.blade.php ENDPATH**/ ?>