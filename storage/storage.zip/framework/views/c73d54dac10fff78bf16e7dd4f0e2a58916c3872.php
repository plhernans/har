    <div class="embarque-datalle col-sm-12 col-md-12 col-lg-12 col-xl-12" hidden>
        <?php echo $__env->make('embarques.m-orden', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="div-mbody-detalle col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

            <div class="col-12 p-2">
                <div class="col-12 div-mdetalle pl-0">
                    <h4><?php echo e(__('Embarque - Detalles')); ?></h4>
                    <br>

                    <div class="row d-flex justify-content-between align-items-center ">
                        <h5 class="ml-4"><?php echo e(__('No. Embarque:')); ?></h5> <label class="lblnoembarque-detalle ml-2 mt-1" for="noembarque"></label>
                        <button type="button" class="btn-nuevaorden btn btn-sm btn-primary rounded ml-auto "><?php echo e(__("Crear Nueva Orden")); ?></button>
                    </div>


                </div>

                <table class="table table-hover table-sm table-responsive-sm tablelistadoordenes">
                    <thead class="thead-light">
                        <tr class="justify-content-between">
                            <th scope="col"  class="bg-light"><?php echo e(__("No. Orden")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Fecha")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Cant. Bultos")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Remitente")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("Destinatario")); ?></th>
                            <th scope="col"  class="bg-light"><?php echo e(__("BL House")); ?></th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr data-noorden='ENV0001-2021' data-remitente='PEDRO LUIS HERNANDEZ SAUMELL'>
                            <td class="rowtdordenes">ENV0001-2021</td>
                            <td class="rowtdordenes">25-09-2021</td>
                            <td class="rowtdordenes">25</td>
                            <td class="rowtdordenes">PEDRO LUIS HERNANDEZ SAUMELL</td>
                            <td class="rowtdordenes">MARTHA IRMA SAUMELL SUGVE</td>
                            <td class="rowtdordenes">HBL-ENV0001-2021</td>

                        </tr>
                        <tr data-noorden='ENA0001-2021' data-remitente='EDUARDO HERNANDEZ HERNANDEZ'>
                            <td class="rowtdordenes">ENA0001-2021</td>
                            <td class="rowtdordenes">28-09-2021</td>
                            <td class="rowtdordenes">50</td>
                            <td class="rowtdordenes">EDUARDO HERNANDEZ HERNANDEZ</td>
                            <td class="rowtdordenes">EDUARDO HERNANDEZ HERNANDEZ</td>
                            <td class="rowtdordenes">HBL-ENA0001-2021</td>

                        </tr>
                    </tbody>
                </table>
            </div>


        </div>
        <div class="row d-flex justify-content-between align-items-center mr-2">
            <button class="btn btn-sm btn-danger ml-auto btncerrar-embarquedetalle"><?php echo e(__("Cerrar")); ?></button>
        </div>
    </div>
<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/embarques/embarquedetalle.blade.php ENDPATH**/ ?>