<div class="modal mt-5 fade" id="mViaje">
    <div id="mViajeDialog" class="modal-dialog modal-lg-dialog mViaje">
        <div class="modal-content">
            <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

            <?php $buques = app('App\Services\Buques'); ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 m-0 p-0">
                <form id="formViaje" class="formViaje" method="POST" action="<?php echo e(route('tcviaje.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('partials._session-msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-12 col-xl-12 m-auto p-0">
                        <div class="card">
                            <div class="card-body">
                                <div id="fieldViaje" class="form-row">
                                    <div class="form-group col-sm-6 mr-4">
                                        <input id="idviaje" class="form-control form-control-sm idviaje" type="text" name="idviaje" hidden>
                                        <input id="idbuque" class="form-control form-control-sm idbuque" type="text" name="idbuque" hidden>
                                    </div>
                                    <div class="form-group col-sm-6 mr-4">
                                        <label for="lblbuque"><strong><?php echo e(__("Buque")); ?></strong></label>
                                        <select name="buque"
                                                class="selectpicker show-menu-arrow form-control buque"
                                                data-live-search="true"
                                                required>
                                            <?php $__currentLoopData = $buques->getBuques(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buque=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-tokens="<?php echo e($buque); ?>" value="<?php echo e($buque); ?>"> <?php echo e($name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input type="text" id="buquetxt" class="form-control buquetxt" type="text" name="buquetxt" required hidden disabled>
                                    </div>



                                    <div class="form-group col-sm-5">
                                        <label for="lblviaje"><strong><?php echo e(__("Viaje")); ?></strong></label>
                                        <input type="text" id="viaje" class="form-control viaje" type="text" name="viaje" required>
                                    </div>
                                </div>
                            </div>
                            <div class="car-footer ml-auto mr-4">
                                <button id="btnSaveViaje" class="btn btn-sm btn-primary mb-2"><?php echo e(__("Guardar")); ?></button>
                                <button id="btnUpdateViaje" class="btn btn-sm btn-outline-primary mb-2" hidden><?php echo e(__("Actualizar")); ?></button>
                                <button type="button" class="btn btn-sm btn-danger mb-2 btnCloseViaje"><?php echo e(__("Cerrar")); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <a id="urlviajeupdate" href="<?php echo e(route('tcviaje.update','')); ?>" hidden></a>
            </div>

        </div>
    </div>
</div>




<?php /**PATH D:\Workspace\www\desarrollo\gloshima\resources\views/modals/mViaje.blade.php ENDPATH**/ ?>